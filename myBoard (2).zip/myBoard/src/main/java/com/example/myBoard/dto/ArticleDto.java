package com.example.myBoard.dto;

import com.example.myBoard.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleDto {
    private Long id;
    private String title;
    private String content;

    public static Article DtoToEntity(ArticleDto articleDto){
        return new Article(
                articleDto.getId(),
                articleDto.getTitle(),
                articleDto.getContent()
        );
    }

    public static ArticleDto EntityToDto(Article articleEntity){
        return new ArticleDto(
                articleEntity.getId(),
                articleEntity.getTitle(),
                articleEntity.getContent()
        );
    }
}
