package com.example.myBoard.entity;

import com.example.myBoard.constant.UserRole;
import groovyjarjarpicocli.CommandLine;
import jakarta.persistence.*;
import lombok.Data;
import org.springframework.context.annotation.Role;

@Entity
@Data
public class UserAccount {
    @Id
    @Column(length = 50, name = "user_id")
    private String username;
    @Column(nullable = false)
    private String password;
    @Column(length = 100)
    private String email;
    @Column(name = "nickname" , length = 50)
    private String nickname;
    @Enumerated(EnumType.STRING)
    private UserRole userRole;
}
