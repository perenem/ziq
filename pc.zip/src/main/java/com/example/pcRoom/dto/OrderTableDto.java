package com.example.pcRoom.dto;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderTableDto {
    private Long id;

    private String userId;

    private int menuId;

    private int orderAmount;
}
