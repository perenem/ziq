package com.example.myBoard.config;

import com.example.myBoard.service.PrincipalOauth2UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private PrincipalOauth2UserService principalOauth2UserService;

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.authorizeHttpRequests((request)-> request
                .requestMatchers("/css/**", "/java/**" ,"/images/**").permitAll()
                .requestMatchers("/user/**").permitAll()
                .requestMatchers("/**").permitAll())
//                .anyRequest().authenticated())

                .formLogin((form)->form
                    .loginPage("/user/login")
                    .loginProcessingUrl("/login")
//                        .usernameParameter("email")  //이메일로 로그인을한다. 이것으로 하려면 repository에 쿼리메서드를 활용하여 작성해주어야한다.
                    .defaultSuccessUrl("/articles/paging", true))

                .logout((out)->out
                        .logoutSuccessUrl("/")
                        .logoutUrl("/logout"))

                .oauth2Login(oAuth->oAuth
                        .loginPage("/user/login")
                        .defaultSuccessUrl("/")
                        .userInfoEndpoint(userInfo->userInfo.userService(principalOauth2UserService)))

                .csrf(csrf -> csrf.disable());
        return http.build();
    }
}
