package com.example.myBoard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class RedirectControllerTest {
    String url = "page";
    String redirect_url = "redirect:" + url;
    @GetMapping("/page")
    public String view(Model model){
        model.addAttribute("message" , "안녕하세요");
        return "/test/page";
    }

    @GetMapping("/test1")
    public String test1(Model model){
        model.addAttribute("message", redirect_url);
        return redirect_url; //return redirect:page
    }

    @GetMapping("/test2")
    public ModelAndView test(Model model){
        model.addAttribute("message" , redirect_url);
        return new ModelAndView(redirect_url);
    }

    @GetMapping("/test3")
    public RedirectView test3(Model model , RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("message" , redirect_url);
            RedirectView redirectView = new RedirectView();
            redirectView.setUrl(url);
            return redirectView;
    }
}
