package com.example.myBoard.controller;

import com.example.myBoard.dto.UserCreateForm;
import com.example.myBoard.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
@Slf4j
public class UserAccountController {
    private final UserService userService;

    public UserAccountController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String signUp(UserCreateForm userCreateForm){
        return "/signup";
    }

    @PostMapping("/signup")
    public String signUpPost(@Valid UserCreateForm userCreateForm,
                             BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            return "/signup";
        }

        if(!(userCreateForm.getPassword1().equals(userCreateForm.getPassword2()))){
            bindingResult.rejectValue("password2" , "password incorrect" ,"비밀번호가 일치하지 않습니다");
            return "signUp";
        }
        try{
            userService.createUser(userCreateForm);
        } catch(DataIntegrityViolationException e){ //동일한 사용자
            e.printStackTrace();
            bindingResult.reject("signupFailed" , "이미 등록된 사용자 입니다.");
            return "signup";
        }catch (Exception e){
            bindingResult.reject("signupFailed" , e.getMessage());
            return "signup";
        }
        return "redirect:/";
    }

    @GetMapping("/login")
    public String login(){
        return "/login";
    }

}
