package com.example.myBoard.service;

import com.example.myBoard.constant.UserRole;
import com.example.myBoard.dto.UserCreateForm;
import com.example.myBoard.entity.UserAccount;
import com.example.myBoard.repository.UserAccountRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserAccountRepository  userAccountRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    @PersistenceContext
    EntityManager em;

    @Transactional
    public void createUser(UserCreateForm userCreateForm) {
        UserAccount userAccount = new UserAccount();
        userAccount.setUserId(userCreateForm.getUsername());
        userAccount.setUserPassword(passwordEncoder.encode(
                userCreateForm.getPassword1()
        ));
        userAccount.setEmail(userCreateForm.getEmail());
        userAccount.setNickname(userCreateForm.getNickname());
        if("ADMIN".equals(userCreateForm.getUsername().toUpperCase())){
            userAccount.setUserRole(UserRole.ADMIN);
        }else{
            userAccount.setUserRole(UserRole.USER);
        }
        em.persist(userAccount); //persist -> save
    }
}
