package com.example.myBoard.controller;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.service.ArticleService;
import com.example.myBoard.service.PaginationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;

@Controller
@Slf4j
public class ArticleController {
    @Autowired
    PaginationService paginationService;
    public final ArticleService articleService;

    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping("/articles/paging")
    public String testView(Model model ,
                           @PageableDefault(page = 0, size = 10 , sort = "id",
                            direction = Sort.Direction.DESC) Pageable pageable){
        // 넘겨온 페이지 번호로 리스트 받아오기
        Page<Article> articlePage = articleService.pagingList(pageable);

        //페이지 블럭 처리(1,2,3,4,5)
        int totalPage = articlePage.getTotalPages();
        List<Integer> barNumbers = paginationService.getPaginationBarNumbers(pageable.getPageNumber(),totalPage);

        model.addAttribute("paginationBarNumbers", barNumbers);
        model.addAttribute("paging" , articlePage);
        return "articles/show_all_new";
    }

    @GetMapping("/articles/insert")
    public String insertView(Model model , ArticleDto articleDto){
        model.addAttribute("dto" , articleDto);
        return "/articles/insert";
    }

    @PostMapping("/articles/insert")
    public String insert(@ModelAttribute("dto") ArticleDto dto){
        articleService.insertData(dto);
        return "redirect:/";
    }

    @GetMapping("/articles/update/{updateId}")
    public String updateView(@PathVariable("updateId") Long id, Model model){
        ArticleDto articleDto;
        articleDto = articleService.findOne(id);
        model.addAttribute("dto" , articleDto);
        return "/articles/update";
    }

    @PostMapping("/articles/update")
    public String update(@ModelAttribute("dto") ArticleDto dto){
        articleService.update(dto);
        return "redirect:/";
    }

    @GetMapping("/articles/delete/{deleteId}")
    public String delete(@ModelAttribute("deleteId") Long id,
                         RedirectAttributes redirectAttributes,
                         Model model){
        // 1. 삭제할 대상이 존재하는지 확인
        ArticleDto articleDto = articleService.findOne(id);
        // 2. 대상 Entity가 존재하면 삭제 처리 후 메세지를 전송
        if(articleDto != null){
            articleService.delete(id);
            redirectAttributes.addFlashAttribute("message" , "정상적으로 삭제되었습니다");
        }
        return "redirect:/";
    }

    @GetMapping("/articles/detail/{id}")
    public String detail(@ModelAttribute("id") Long id , Model model){
        ArticleDto dto = articleService.findOne(id);
        model.addAttribute("dto", dto);
        return "/articles/detail";
    }
}
