package com.example.myBoard.constant;

import lombok.Data;
import lombok.Getter;
import org.apache.catalina.User;

@Getter
public enum UserRole {
    ADMIN("ROLE ADMIN"),
    USER("ROLE USER");

    private String value;

    UserRole(String value){
        this.value = value;
    }
}
