package com.example.thymeleafTest.vo;

public class MemberUser {
    private String uName;
    private String addr;


    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public MemberUser(String uName, String addr) {
        this.uName = uName;
        this.addr = addr;
    }
}
