package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.MemberUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@Controller
public class MemberController1 {
    @GetMapping("/member1")
    public String member(Model model) {
        addMemberUser(model);

        return "articles/member1";

    }

    private void addMemberUser(Model model) {
        List<MemberUser> userList = new ArrayList<>(
                Arrays.asList(
                        new MemberUser("Name_01", "addr_01"),
                        new MemberUser("Name_02", "addr_02"),
                        new MemberUser("Name_03", "addr_03"),
                        new MemberUser("Name_04", "addr_04"),
                        new MemberUser("Name_05", "addr_05"),
                        new MemberUser("Name_06", "addr_06"),
                        new MemberUser("Name_07", "addr_07"),
                        new MemberUser("Name_08", "addr_08"),
                        new MemberUser("Name_09", "addr_09"),
                        new MemberUser("Name_10", "addr_10"),
                        new MemberUser("Name_11", "addr_11"),
                        new MemberUser("Name_12", "addr_12"),
                        new MemberUser("Name_13", "addr_13"),
                        new MemberUser("Name_14", "addr_14"),
                        new MemberUser("Name_15", "addr_15")
                )
        );
        model.addAttribute("MemberUser", userList);
    }
    }
