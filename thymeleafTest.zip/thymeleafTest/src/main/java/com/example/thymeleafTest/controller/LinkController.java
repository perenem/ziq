package com.example.thymeleafTest.controller;

import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LinkController {
    @GetMapping("/link")
    public String link(Model model) {
        model.addAttribute("name", "장원영");
        model.addAttribute("age", 21);
        return "link/linkView";
    }

    // @GetMapping("")

    @GetMapping("/requestParam")
    public String reqParam(@RequestParam("name") String name ,
                           @RequestParam("age") int age,
                           Model model){
        model.addAttribute("name", name);
        model.addAttribute("age", age);
        model.addAttribute("title", "Request Param :");
        return "link/resultView";
    }

    @GetMapping("/pathVariable/{name}/{age}")
    // http://localhost/pathVariable/장원영/21

    public String pathVariable(@PathVariable("name") String name,
                               @PathVariable("age") int age,
                               Model model){
        model.addAttribute("name", name);
        model.addAttribute("age", age);
        model.addAttribute("title", "Path variable :");
        return "link/resultView";
    }

    @GetMapping("/pathAndQuery/{name}")
    public String pathAndQuery(@PathVariable("name") String name,
                               @RequestParam("age") int age,
                               Model model){
        model.addAttribute("name", name);
        model.addAttribute("age", age);
        model.addAttribute("title", "Path variable + query parameter :");
        return "link/resultView";

    }
}
