package com.example.thymeleafTest.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Data  // getter , setter , tostring 까지 모두 포함하는게
       // data 이지만 각각을 사용할때는 개별적으로 사용하는게 좋다.
public class FormDto {
    private String name;
    private boolean trueOrFalse;
    private List<String> hobbies;  //multi-checkbox
    private String language; //radio-button
    private String country; // select
}