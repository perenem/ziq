package com.example.thymeleafTest.controller;// FormControlController.java

import com.example.thymeleafTest.vo.Agree;
import com.example.thymeleafTest.vo.Gender;
import com.example.thymeleafTest.vo.InputDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class FormControlController {
    @ModelAttribute("gender")
    private Gender[] genders(){
        return Gender.values();
    }
    @ModelAttribute("agree")
    private Agree[] agrees(){
        return Agree.values();
    }
    @GetMapping("/signUp")
    public String formControl(Model model){
        model.addAttribute("dto", new InputDto());
        model.addAttribute("confirmpassword", new InputDto());
        return "/signUp";
    }
    @PostMapping("/signUp")
    public String postSignUp(InputDto dto) {
        log.info("InputDto.id = " + dto.getId());
        log.info("InputDto.password = " + dto.getPassword());
        log.info("InputDto.trueOrFalse = " + dto.isTrueOrFalse());
    return "/signUp";
    }
}
