package com.example.thymeleafTest.vo;

import lombok.Getter;

@Getter
public enum Agree {
    AGREE1("이용약관 동의(필수)"),
    AGREE2("개인정보 필수 동의"),
    AGREE3("개인정보 선택 동의");
    private final String description;

    Agree(String description) {
        this.description = description;
    }
}
