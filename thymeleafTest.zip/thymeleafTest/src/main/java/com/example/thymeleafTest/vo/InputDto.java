package com.example.thymeleafTest.vo;// InputDto.java

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InputDto {
    private String id;
    private String name;
    private String password;
    private String Email;
    private int tel;
    private boolean trueOrFalse;
    private String gender; //radio-button
    private int birth;
    private String agree;

}
