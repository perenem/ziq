package com.example.pcRoom.service;

import com.example.pcRoom.dto.UsersDto;
import com.example.pcRoom.entity.Users;
import com.example.pcRoom.repository.UsersRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    UsersDto usersDto = new UsersDto();
    private UsersRepository usersRepository;

    public UserService(UsersRepository userRepository) {
        this.usersRepository = userRepository;
    }

    public void chargeUser(UsersDto usersDto) {
        Users user = usersRepository.findById(usersDto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        int currentMoney = user.getMoney();
        int chargedAmount = user.getChargedAmount();

        // 충전된 금액을 누적하여 업데이트
        user.setMoney(currentMoney + usersDto.getChargedAmount());
        user.setChargedAmount(chargedAmount + usersDto.getChargedAmount());

        usersRepository.save(user);
    }

}
