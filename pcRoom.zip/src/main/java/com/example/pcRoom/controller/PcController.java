package com.example.pcRoom.controller;

import com.example.pcRoom.dto.SellDto;
import com.example.pcRoom.dto.UsersDto;
import com.example.pcRoom.service.AdminService;
import com.example.pcRoom.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class PcController {

    @Autowired
    private final AdminService adminService;
    private final UserService userService;

    public PcController(AdminService adminService, UserService userService) {
        this.adminService = adminService;
        this.userService = userService;
    }

    @GetMapping("")
    public String userMainPage(){

        return "user/user_main";
    }

    // 물건팔기 페이지로
    @GetMapping("/user")
    public String sell(Model model) {
        List<SellDto> sellDtoList = adminService.sell();
        model.addAttribute("sellDto", sellDtoList);
        return "/admin/sell";
    }

    //금액 충전 페이지에 대한 get
    @GetMapping("/insert")
    public String insertCoinForm(Model model){
        model.addAttribute("usersDto", new UsersDto());
        return "/admin/insert_coin";
    }

    //금액 충전 페이지에 대한 post
    @PostMapping("/insert_coin")
    public String insertCoin(@ModelAttribute("usersDto") UsersDto usersDto){
        userService.chargeUser(usersDto);
        return "redirect:";
    }
}