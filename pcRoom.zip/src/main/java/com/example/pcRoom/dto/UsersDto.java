package com.example.pcRoom.dto;

import com.example.pcRoom.entity.Users;
import jakarta.persistence.Column;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsersDto {

    private String userId;
    private String name;
    private String password;
    private int money;
    private int chargedAmount;
    private String status; //관리자 , 일반

    public static UsersDto fromUserEntity(Users users) {
        return new UsersDto(
                users.getUserId(),
                users.getName(),
                users.getPassword(),
                users.getMoney(),
                users.getChargedAmount(),
                users.getStatus()
        );
    }
    public static Users fromUsers(UsersDto usersDto){
        Users users = new Users();
                usersDto.setUserId(usersDto.getUserId());
                usersDto.setName(usersDto.getName());
                usersDto.setPassword(usersDto.getPassword());
                usersDto.setMoney(usersDto.getMoney());
                usersDto.setChargedAmount(usersDto.getChargedAmount());
                usersDto.setStatus(usersDto.getStatus());
        return users;
    }
}
