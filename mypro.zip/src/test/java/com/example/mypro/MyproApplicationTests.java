package com.example.mypro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyproApplicationTests {

	@Test
	void contextLoads() {
	}

}
