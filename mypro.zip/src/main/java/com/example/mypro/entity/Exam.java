// Exam.java
package com.example.mypro.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "exam")
@NoArgsConstructor
@AllArgsConstructor
public class Exam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 6 , nullable = false)
    private Long examNo;

    @Column(length = 10)
    private int kor;
    @Column(length = 15)
    private int math;
    @Column(length = 4)
    private int eng;
    @Column(length = 20)
    private int hist;
}
