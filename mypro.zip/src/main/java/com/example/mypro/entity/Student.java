// Student.java
package com.example.mypro.entity;

import com.example.mypro.genderenum.Gender;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@Table(name = "student")
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 6 , nullable = false)
    private Long studentNo;
    @Column(length = 10)
    private String name;
    @Column(length = 15)
    private String phone;
    @Enumerated(EnumType.STRING)
    private Gender gender;
    @Column(length = 20)
    private String address;
}
