package com.example.mypro.controller;

import com.example.mypro.dto.ExamDto;
import com.example.mypro.entity.Exam;
import com.example.mypro.entity.Student;
import com.example.mypro.repository.ExamRepository;
import com.example.mypro.service.EntityService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

@Controller
public class controller {

    private final EntityService entityService;
    private ExamRepository examRepository;

    public controller(EntityService entityService) {
        this.entityService = entityService;
    }

    // 메인 화면
    @GetMapping("/home")
    public String home(Model model){
        return "/home";
    }

    // 학생 목록 조회
    @GetMapping("showall")
    public String showAll(Model model){
        List<Student> students = entityService.getAllStudents();
        model.addAttribute("students", students);
        return "/showallstudent";
    }

    // 성적 입력 폼
    @GetMapping("insertexam")
    public String insertForm(Model model){
        model.addAttribute("exam", new ExamDto());
        return "/insert";
    }

    // 성적 입력 처리
    @PostMapping("/insert")
    public String insertExam(@Valid @ModelAttribute("examDto") ExamDto examDto , BindingResult bindingResult) {
        if (bindingResult.hasErrors()){
            return "/insert";
        }
        entityService.insertExam(examDto);
        return "redirect:/showall";
    }
    @GetMapping("/showexam")
    public String showAllExam(Model model){
        List<Exam> exams = entityService.getAllexams();
        int sumExam = entityService.sumExam();
        model.addAttribute("exams", exams);
        model.addAttribute("sumExam", sumExam);
        return "/showexam";
    }

    public int sumExam(){
        return examRepository.sumExam();

    }

}
