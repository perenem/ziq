package com.example.mypro.genderenum;

public enum Gender {
    M,
    F
}
