// EntityService.java
package com.example.mypro.service;

import com.example.mypro.dto.ExamDto;
import com.example.mypro.entity.Exam;
import com.example.mypro.entity.Student;
import com.example.mypro.repository.ExamRepository;
import org.springframework.stereotype.Service;
import com.example.mypro.repository.StudentRepository;

import java.util.List;

@Service
public class EntityService {

    private final StudentRepository studentRepository;
    private final ExamRepository examRepository;

    public EntityService(StudentRepository studentRepository, ExamRepository examRepository) {
        this.studentRepository = studentRepository;
        this.examRepository = examRepository;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public void insertExam(ExamDto dto) {
        Exam exam = ExamDto.DtoToEntity(dto);
        examRepository.save(exam);
        }

    public List<Exam> getAllexams() {
        return examRepository.findAll();
    }
}


