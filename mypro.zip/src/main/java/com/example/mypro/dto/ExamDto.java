package com.example.mypro.dto;

import com.example.mypro.entity.Exam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExamDto {
    private Long examNo;
    private int kor;
    private int math;
    private int eng;
    private int hist;

    public static ExamDto EntityToDto(Exam exam){
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist());
    }

    public static Exam DtoToEntity(ExamDto examDto){
        return new Exam(examDto.getExamNo()
                , examDto.getKor(), examDto.getMath(), examDto.getEng(), examDto.getHist());
    }
}
