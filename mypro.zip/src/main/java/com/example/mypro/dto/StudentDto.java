package com.example.mypro.dto;

import com.example.mypro.genderenum.Gender;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StudentDto {
    private Long StudentNo;
    private String name;
    private String phone;
    private Gender gender;
    private String address;
    private ExamDto examDto;
}
