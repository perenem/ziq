package com.example.basiccrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
